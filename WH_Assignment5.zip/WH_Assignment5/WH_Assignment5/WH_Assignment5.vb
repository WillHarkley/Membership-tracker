﻿Public Class frmAssignment5

    'Name: Assignment 5
    'Purpose: To add, delete and count members in a program. You can also create new files based on new programs
    'Programmer: William Harkley

    'The identifying variable for the text file
    Dim textfile As String

    Private Sub frmAssignment5_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'brings in the original text file into the program
        textfile = "Members.txt"
        'Error check
        cleanList()
    End Sub

    Private Sub mnuExit_Click(sender As Object, e As EventArgs) Handles mnuExit.Click
        'closes app
        Me.Close()
    End Sub

    Private Sub mnuAscend_Click(sender As Object, e As EventArgs) Handles mnuAscend.Click
        'Sorts names in ascending order
        Dim ascendquery = From members In IO.File.ReadAllLines(textfile)
                          Order By members Ascending
                          Select members

        lstDisplay.DataSource = ascendquery.ToList()
    End Sub

    Private Sub mnuDescend_Click(sender As Object, e As EventArgs) Handles mnuDescend.Click
        'Sorts names in descending order
        Dim descendquery = From members In IO.File.ReadAllLines(textfile)
                           Order By members Descending
                           Select members

        lstDisplay.DataSource = descendquery.ToList()
    End Sub

    'Displays the desired results
    Sub cleanList()
        lstDisplay.DataSource = IO.File.ReadAllLines(textfile)
        lstDisplay.SelectedItem = Nothing
        txtCount.Text = lstDisplay.Items.Count
    End Sub

    Private Sub mnuAdd_Click(sender As Object, e As EventArgs) Handles mnuAdd.Click
        'This is to add a new member
        Dim newmember As String = InputBox("Please enter the full name of the new member")
        'error check newmember

        Dim sw As IO.StreamWriter

        sw = IO.File.AppendText(textfile)
        sw.WriteLine(newmember)
        sw.Close()

        cleanList()
    End Sub

    Private Sub mnuDelete_Click(sender As Object, e As EventArgs) Handles mnuDelete.Click
        'This is to delete a member when selected
        Dim deletemember As String
        'error check
        deletemember = lstDisplay.SelectedItem

        Dim deletequery = From reading In IO.File.ReadAllLines(textfile)
                          Where reading <> deletemember
                          Select reading

        IO.File.WriteAllLines(textfile, deletequery)
        cleanList()
    End Sub

    Private Sub mnuCreate_Click(sender As Object, e As EventArgs) Handles mnuCreate.Click
        'This is to create a new file
        Dim filecreate = InputBox("Please enter name of new file")
        'error check
        textfile = filecreate & ".txt"
        'error check to see if file exists
        Dim sw As IO.StreamWriter = IO.File.CreateText(textfile)
        sw.Close()

        cleanList()
    End Sub
End Class
